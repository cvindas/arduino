# ECG-Box
Monitor cardiaco en Arduino y aplicacion para Android via bluetooth

#Creditos
* Joksan Alvarado (joksan.alvarado@gmail.com)
* Karla Hernandez (karla.hdz4@gmail.com) 
* Jose Carlos Garcia (chepecarlos@alswblog.org)
