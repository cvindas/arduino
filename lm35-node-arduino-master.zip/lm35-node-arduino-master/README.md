# Issues
- https://github.com/firmata/arduino/issues/334
- https://heliosoph.wordpress.com/2012/03/21/connecting-an-arduino-with-a-lm35-temperature-sensor-special-issues/
