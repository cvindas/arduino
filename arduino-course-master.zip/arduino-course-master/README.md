# Index
- basics
- blink_led
- measuring_light

## Components
  - Leds:
    - http://electronicsclub.info/leds.htm

## tools

- resistor calcultor: http://www.evilmadscientist.com/2009/wallet-size-led-resistance-calculator/
- multiples Leds: http://www.instructables.com/id/How-to-make-a-string-of-LEDs-in-parallelfor-ardu/
- pwm:
http://makezine.com/2011/06/01/circuit-skills-pwm-pulse-widthmodulation-sponsored-by-jameco-electronics/
